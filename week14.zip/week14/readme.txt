open this folder in vs code 
then type "cd restapi" in terminal 
then type "py manage.py runserver"
server will start running on port 8000
goto "localhost:8000" and register a user and search for that user 
thats it
Note: user id should be of only number no characters are allowed