open this folder in vs code 
enter "cd week11" command this will take it to the project folder
now enter "npm start" command
it will compile and get executed and the server will start
it will automatically redirect to the website if not go to "localhost:3000"
you will see the output