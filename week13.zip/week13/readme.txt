open this folder in vs code
enter "cd week13" command
again enter "python manage.py runserver" commandthis will start the server go to "localhost:8000"
you will see the output