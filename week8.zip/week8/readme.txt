open this folder in vs code
enter the command "node server.js"
the server will start running
open mongodb and click on connect
click on plus icon on left side beside databases
enter database name as cse and collection name as employee
goto "localhost:3000" you will see output just signup and login with same details