open this folder in vs code
just run "ng serve"
after entering this command the server will start running
goto "localhost:4200"
you will see the output