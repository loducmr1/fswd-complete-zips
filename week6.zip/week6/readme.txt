open the folder in vs code
type "node server.js"
this will run the server just go to "localhost:3000"
you will see the output
enter "jyotsna" as username and "abc" as password
you will se verified user and try to enter another details for another output