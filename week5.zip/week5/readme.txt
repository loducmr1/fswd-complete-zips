open the folder in vs code
type "node server.js"
this will run the server just go to "localhost:3000"
you will see the output